# peddit

# disclaimer
This is a personal open source project and i dont own any rights on Reddit Inc.

# Installation Instructions
You need to have NodeJS installed on your device (tested on NodeJS V16.13.2 LTS) and if you are running linux
you need the gnome-keyring, otherwise the app wont work at all.

First you have to install all dependencies:
npm i

Then you can run the App with:
npx electron .

# Additional Informations
This App isnt finished yet and some features (like the settings) dont work at all right now.
