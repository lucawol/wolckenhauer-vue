"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.refreshBearerToken = void 0;
const axios_1 = require("axios");
const buffer_1 = require("buffer");
const refreshBearerToken = async (token) => {
    return new Promise((resolve, reject) => {
        if (token != null) {
            var username = "PHEUmq2h-RKNLeLWVxL0pA";
            var password = "";
            var reqString = "grant_type=refresh_token&refresh_token=" + token;
            (0, axios_1.default)({
                method: "post",
                url: "https://www.reddit.com/api/v1/access_token",
                headers: {
                    Authorization: "Basic " + buffer_1.Buffer.from(username + ":" + password).toString('base64')
                },
                data: reqString
            })
                .then(res => {
                resolve(res.data);
            })
                .catch(err => {
                reject(err);
            });
        }
    });
};
exports.refreshBearerToken = refreshBearerToken;
//# sourceMappingURL=refreshBearerToken.js.map