"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedditJuice = void 0;
const fetchRedditComments_1 = require("./ApiFunc/fetchRedditComments");
const fetchRedditFeed_1 = require("./ApiFunc/fetchRedditFeed");
const fetchBearerToken_1 = require("./ApiFunc/fetchBearerToken");
const refreshBearerToken_1 = require("./ApiFunc/refreshBearerToken");
const keytar = require("keytar");
const os = require("os");
const keytarService = "peddit-auth";
const keytarAccount = os.userInfo().username;
class RedditJuice {
    constructor() {
        this.afterbeforeStorage = [];
        this.totalPage = 0;
        this.currentPage = 0;
    }
    async nextPost() {
        this.currentPage = this.currentPage + 1;
        this.totalPage = this.totalPage + 1;
        if (Math.trunc((this.currentPage / 25)) == 1) {
            if (!this.afterbeforeStorage.includes(this.pageStorage.after)) {
                this.afterbeforeStorage.push(this.pageStorage.after);
            }
            if (this.afterbeforeStorage.length < 3) {
                var afterTag = Math.trunc((this.totalPage / 25) - 1);
                var beforeTag = Math.trunc(this.totalPage / 25);
            }
            else {
                var afterTag = Math.trunc((this.totalPage / 25) - 1);
                var beforeTag = Math.trunc((this.totalPage / 25) + 1);
            }
            this.currentPage = 0;
            this.pageStorage = await (0, fetchRedditFeed_1.fetchRedditFeed)(this.afterbeforeStorage[afterTag], this.afterbeforeStorage[beforeTag], this.bearertoken);
        }
    }
    async setBearerToken(code) {
        var token = await (0, fetchBearerToken_1.fetchBearerToken)(code);
        await keytar.setPassword(keytarService, keytarAccount, token.refresh_token);
        this.bearertoken = token.access_token;
        this.refreshtoken = token.refresh_token;
    }
    async logBearerToken() {
        console.log(this.bearertoken);
        console.log(this.refreshtoken);
    }
    async prevPost() {
        if (this.totalPage != 0) {
            this.currentPage = this.currentPage - 1;
            this.totalPage = this.totalPage - 1;
            if (this.currentPage < 0) {
                if (this.afterbeforeStorage.length < 3) {
                    var afterTag = Math.trunc(this.totalPage / 25);
                    var beforeTag = Math.trunc((this.totalPage / 25) - 1);
                }
                else {
                    var afterTag = Math.trunc((this.totalPage / 25) - 1);
                    var beforeTag = Math.trunc((this.totalPage / 25) + 1);
                }
                console.log("rebuild posts");
                this.currentPage = 24;
                this.pageStorage = await (0, fetchRedditFeed_1.fetchRedditFeed)(this.afterbeforeStorage[afterTag], this.afterbeforeStorage[beforeTag], this.bearertoken);
            }
        }
    }
    async getRedditPage() {
        return this.pageStorage.children[this.currentPage];
    }
    async getRedditComments() {
        var permalink = this.pageStorage.children[this.currentPage].data.permalink;
        return await (0, fetchRedditComments_1.fetchPostComments)(permalink);
    }
    async init() {
        this.pageStorage = "";
        this.currentPage = 0;
        this.totalPage = 0;
        var refreshToken = await keytar.getPassword(keytarService, keytarAccount);
        if (refreshToken != null) {
            var newBearer = await (0, refreshBearerToken_1.refreshBearerToken)(refreshToken);
            this.bearertoken = newBearer.access_token;
            setInterval(async () => {
                this.bearertoken = await (0, refreshBearerToken_1.refreshBearerToken)(refreshToken);
            }, 3600);
        }
        this.pageStorage = await (0, fetchRedditFeed_1.fetchRedditFeed)("", "", this.bearertoken);
    }
}
exports.RedditJuice = RedditJuice;
//# sourceMappingURL=RedditJuice.js.map