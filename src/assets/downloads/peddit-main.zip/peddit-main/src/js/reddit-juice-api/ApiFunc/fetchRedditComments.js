"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchPostComments = void 0;
const axios_1 = require("axios");
const fetchPostComments = async (permalink) => {
    return new Promise((resolve, reject) => {
        var comment_fetch_url = "https://reddit.com" + permalink + '.json?limit=10';
        axios_1.default.get(comment_fetch_url)
            .then(res => {
            resolve(res.data[1]);
        })
            .catch(err => {
            reject(err);
        });
    });
};
exports.fetchPostComments = fetchPostComments;
//# sourceMappingURL=fetchRedditComments.js.map