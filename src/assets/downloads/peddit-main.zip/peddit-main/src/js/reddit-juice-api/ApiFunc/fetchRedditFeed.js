"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchRedditFeed = void 0;
const axios_1 = require("axios");
const fetchRedditFeed = async (afterTag, beforeTag, bearer) => {
    return new Promise((resolve, reject) => {
        if (bearer == undefined) {
            if ((afterTag?.length == 0 || afterTag == "") && (beforeTag?.length == 0 || beforeTag == "" || beforeTag == undefined)) {
                var url = "https://reddit.com/.json";
            }
            else if (beforeTag?.length == 0 || beforeTag == "" || beforeTag == undefined) {
                var url = "https://reddit.com/.json?after=" + afterTag;
            }
            else {
                var url = "https://reddit.com/.json?after=" + afterTag + "?before=" + beforeTag;
            }
        }
        else {
            if ((afterTag?.length == 0 || afterTag == "") && (beforeTag?.length == 0 || beforeTag == "" || beforeTag == undefined)) {
                var url = "https://oauth.reddit.com/.json";
            }
            else if (beforeTag?.length == 0 || beforeTag == "" || beforeTag == undefined) {
                var url = "https://oauth.reddit.com/.json?after=" + afterTag;
            }
            else {
                var url = "https://oauth.reddit.com/.json?after=" + afterTag + "?before=" + beforeTag;
            }
        }
        console.log(url);
        (0, axios_1.default)({
            method: "GET",
            url: url,
            headers: {
                Authorization: "bearer " + bearer
            }
        })
            .then(res => {
            resolve(res.data.data);
        })
            .catch(err => {
            reject(err);
        });
    });
};
exports.fetchRedditFeed = fetchRedditFeed;
//# sourceMappingURL=fetchRedditFeed.js.map