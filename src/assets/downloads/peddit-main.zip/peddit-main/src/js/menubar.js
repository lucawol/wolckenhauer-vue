document.getElementById("menu-bar-button").addEventListener('click',() => {
    var menubar = document.getElementById("menu-bar-content")
    if(menubar.classList.contains("menu-bar-content-hidden")){
        menubar.classList.remove("menu-bar-content-hidden")
        menubar.classList.add("menu-bar-content")
    }
    else if(menubar.classList.contains("menu-bar-content")){
        menubar.classList.remove("menu-bar-content")
        menubar.classList.add("menu-bar-content-hidden")
    }
})

