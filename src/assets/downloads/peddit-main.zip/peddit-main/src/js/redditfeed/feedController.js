window.api.recieve("pingGUI", async() => {
    console.log('fire!')
    document.getElementById("reddit").innerHTML = ""
    var redditContainer = document.getElementById("reddit")
    var redditContent = document.createElement("div")
    redditContent.id = "redditContent"
    redditContent.className = "redditfeed"
    redditContainer?.appendChild(redditContent)
    var redditComments = document.createElement("div")
    redditComments.id = "redditComments"
    redditComments.className = "redditcomments"
    redditContainer?.appendChild(redditComments)
    var feed = await window.reddit.currentPage()
    var comments = await window.reddit.currentComments()
    buildReddit(feed, comments)
})

const nextButton = document.getElementById("next-btn")
nextButton.addEventListener('click',async () => {
    var redditFeed = await window.reddit.nextPage()
    var redditComm = await window.reddit.currentComments()

    buildReddit(redditFeed, redditComm)
    console.log(redditComm)
})
const prevButton = document.getElementById("prev-btn")
prevButton.addEventListener('click', async () => {
    var redditFeed = await window.reddit.prevPage()
    var redditComm = await window.reddit.currentComments()

    buildReddit(redditFeed, redditComm)
})

const buildReddit = async(currentPost, currentComments) => {
        var redditContent = document.getElementById("redditContent")
        redditContent.innerHTML = ""
        var redditComments = document.getElementById("redditComments")
        redditComments.innerHTML = ""
        var tag = document.createElement("h1")
        var textString = currentPost.data.title
        if(textString.length > 80){
            var title = textString.slice(0, 80)
            var text = document.createTextNode(title)
        }
        else{
            var text = document.createTextNode(currentPost?.data?.title)
        }
        tag.appendChild(text)
        redditContent.appendChild(tag)
        if(currentPost?.data?.post_hint){
            if(currentPost.data.post_hint == "image"){
                var img = new Image()
                img.src = currentPost.data.url
                redditContent.appendChild(img)
            }
        }
        if(currentPost?.data?.selftext) {
            if(currentPost.selftext != ""){
                var tag = document.createElement("p")
                var text = document.createTextNode(currentPost.data.selftext)
                tag.appendChild(text)
                redditContent.appendChild(tag)
            }
        }
        if(currentPost?.data?.is_video) {
            if(currentPost.data.is_video == true){
                var video = document.createElement("video")
                video.autoplay = true
                video.loop = true
                var sourcemp4 = document.createElement("source")
                sourcemp4.src = currentPost.data.secure_media.reddit_video.fallback_url
                video.appendChild(sourcemp4)
                redditContent.appendChild(video)
                
            }
        }
        if(currentPost?.data?.url.includes("mp4") || currentPost?.data?.url.includes("gifv")){
            if(currentPost?.data?.url.includes("gifv")){
                currentPost.data.url = currentPost.data.url.replace(".gifv", ".mp4")
            }
            var video = document.createElement("video")
            video.autoplay = true
            video.src = currentPost.data.url
            redditContent.appendChild(video)
        }
        currentComments.data.children.forEach(element => {
                var author = document.createElement("p")
                author.innerHTML = element.data.author
                var comment = document.createElement("p")
                comment.innerHTML = element.data.body
                redditComments.appendChild(author)
                redditComments.appendChild(comment)

        })
        
}



document.getElementById("menu-settings").addEventListener("click", () => {
    window.open("../views/settings.html", "", "width=1024,height=600")
    var menubar = document.getElementById("menu-bar-content")
    menubar.classList.remove("menu-bar-content")
    menubar.classList.add("menu-bar-content-hidden")
})

document.getElementById("menu-login").addEventListener("click", () => {
    window.reddit.loadLoginWindow()
    menubar.classList.remove("menu-bar-content")
    menubar.classList.add("menu-bar-content-hidden")
})

document.getElementById("menu-exit").addEventListener("click", () => {
    window.close()
})

window.reddit.authReady( async() => {
    console.log('fire2!')
    var redditContainer = document.getElementById("reddit")
    redditContainer.innerHTML = ""
    var redditContent = document.createElement("div")
    redditContent.id = "redditContent"
    redditContent.className = "redditfeed"
    redditContainer?.appendChild(redditContent)
    var redditComments = document.createElement("div")
    redditComments.id = "redditComments"
    redditComments.className = "redditcomments"
    redditContainer?.appendChild(redditComments)
    var feed = await window.reddit.currentPage()
    var comments = await window.reddit.currentComments()
    buildReddit(feed, comments)
})