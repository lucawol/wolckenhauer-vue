var closeWindow = document.getElementById("menu-home")
closeWindow.addEventListener("click", () => {
    window.close()
    menubar.classList.remove("menu-bar-content")
    menubar.classList.add("menu-bar-content-hidden")
})