document.getElementById("top-bar-back").addEventListener("click", () => {
    window.close()
})