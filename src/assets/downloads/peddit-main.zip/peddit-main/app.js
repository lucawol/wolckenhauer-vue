const {app, BrowserWindow, ipcMain, safeStorage, ipcRenderer} = require('electron')
const path = require("path")
const http = require("http")
const fs = require("fs")
const {RedditJuice} = require("./src/js/reddit-juice-api/RedditJuice")

var redditJuice

function createWindow() {
    win = new BrowserWindow({
        width: 1024,
        height: 600,
        resizable: true,
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            enableRemoteModule: false,
            preload: path.join(__dirname, 'preload.js')
        }
    })
    win.loadFile(path.join(__dirname, 'src/views/index.html'))
    redditJuice = new RedditJuice()

    win.webContents.on("did-finish-load", async() => {
        await redditJuice.init()
        win.webContents.send("pingGUI", "ping")
    })
}
function createLoginWindow() {
    const webserver = http.createServer((req, res) => {
        if(req.method == 'POST'){
            var postData
            req.on('data', chunk => {
                postData += chunk.toString()
            })
            req.on("end", async function(){
                res.writeHead(200, { "Content-Type": "text/html" });
                res.end(postData)
                var UrlData = JSON.parse(postData.split("undefined").pop())
                await redditJuice.setBearerToken(UrlData.code)
                await redditJuice.init()
                win.webContents.send("pingGUI", "ping")   
            })

        }
        if(req.method == 'GET'){
            fs.readFile("./login-handler/index.html",async (err, data) => {
                res.writeHead(200, {"Content-Type" : "text/html"})
                res.end(data)
            })
        }

    }).listen(9000)


    
    redditWeb = new BrowserWindow({
        width: 1024,
        height: 600,
        resizable: false,
        autoHideMenuBar: false,
        frame: true,
        webPreferences: {
            nodeIntegration: false
        }
        
    })
    var randomString = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
    var apiURL = "https://www.reddit.com/api/v1/authorize?client_id=PHEUmq2h-RKNLeLWVxL0pA&response_type=code&state=" + randomString + "&redirect_uri=http://localhost:9000&duration=permanent&scope=edit mysubreddits read"
    redditWeb.loadURL(apiURL)
    redditWeb.show()


    redditWeb.on("closed", () => {
        redditWeb = null
    })
}

app.whenReady().then(() => {
    createWindow()
})
ipcMain.on("loadLoginWindow", async (event, data) => {
    createLoginWindow()
})
ipcMain.handle("nextPage", async(event, data) => {
    await redditJuice.nextPost()
    return await redditJuice.getRedditPage()
})
ipcMain.handle("prevPage", async(event, data) => {
    await redditJuice.prevPost()
    return await redditJuice.getRedditPage()
})
ipcMain.handle("currentPage", async(event, data) => {
    return await redditJuice.getRedditPage()
})
ipcMain.handle("currentComments", async(event, data) => {
    return await redditJuice.getRedditComments()
})
ipcMain.on("authData", async(event, data) => {
    console.log(data)
})





