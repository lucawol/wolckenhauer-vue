const {ipcRenderer, contextBridge} = require("electron")

contextBridge.exposeInMainWorld(
    "api", {
        recieve: (channel, func) => {
            if(channel == "pingGUI"){
                ipcRenderer.on("pingGUI", func)
            }
            if(channel == "pingReddit"){
                ipcRenderer.on("pingReddit")
            }

        },
        send: (channel, data) => {
            if(channel == "initGUI"){
                ipcRenderer.send("initGUI")
            }
            if(channel == "initReddit"){
                ipcRenderer.send("initReddit")
            }
        }
    }
    
)

contextBridge.exposeInMainWorld(
    "reddit", {
        nextPage: async(arg) => {  
            return await ipcRenderer.invoke("nextPage", arg)
        },
        prevPage: async(arg) => {  
            return await ipcRenderer.invoke("prevPage", arg)
        },
        currentPage: async(arg) => {  
            return await ipcRenderer.invoke("currentPage", arg)
        },
        currentComments: async(arg) => {
            return await ipcRenderer.invoke("currentComments", arg)
        },
        init: async(arg) => {
            return await ipcRenderer.invoke("initReddit", arg)
        },
        loadLoginWindow: async(arg) => {
            ipcRenderer.send("loadLoginWindow")
        },
        authData: async(arg) => {
            ipcRenderer.send("authData", arg)
        },
        authReady: async(arg) => {
            ipcRenderer.on("authReady", arg)
        }
        

    }
)
